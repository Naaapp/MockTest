#include <stdio.h>

int main(void)
{
	printf("000\n");
	return 0;
}
