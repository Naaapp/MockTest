#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "merkle_tree.c"

//merkle tree test
#define TREE_HEIGHT 10
#define BLOCK_SIZE 1024
#define DATA_BLOCKS 4

int main (int argc, char *argv[])
{

    if (argc != 3)
        return 0;

    int i;
    int j;
    unsigned char *data1[DATA_BLOCKS], *data2[DATA_BLOCKS], buffer1[BLOCK_SIZE], buffer2[BLOCK_SIZE];
    
    // make sure TREE_HEIGHT fits DATA_BLOCKS...
    // BLOCK_SIZE & hash_size, hash_function also needed init
    merkle_tree mt_a = {0, TREE_HEIGHT, MD5_DIGEST_LENGTH, BLOCK_SIZE, DATA_BLOCKS, MD5One, NULL};
    merkle_tree mt_b = {0, TREE_HEIGHT, MD5_DIGEST_LENGTH, BLOCK_SIZE, DATA_BLOCKS, MD5One, NULL};

    
    for (i=0; i<DATA_BLOCKS; i++) {
        for (j=0; j<BLOCK_SIZE; j++){

            if(i * BLOCK_SIZE + j >= 3360){
                buffer1[j] = 'a';
                buffer2[j] = 'a';
            }
            else{
                buffer1[j] = (unsigned char)argv[1][i * BLOCK_SIZE + j];
                buffer2[j] = (unsigned char)argv[2][i * BLOCK_SIZE + j];
                // printf("%d %d %d\n",i,j,buffer1[j]);
            }
        }
        data1[i] = (unsigned char *)malloc(sizeof(char) * BLOCK_SIZE);
        data2[i] = (unsigned char *)malloc(sizeof(char) * BLOCK_SIZE);
        memcpy(data1[i], buffer1, BLOCK_SIZE);
        memcpy(data2[i], buffer2, BLOCK_SIZE);
    }

    // printf("%d %d", data1[0][0],data2[0][0]);

    //build tree mt_a with data
    build_tree(&mt_a, data1);

    build_tree(&mt_b, data2);

    //note : too much data to priny
    // print_tree(&mt_a);
    // print_tree(&mt_b);

    //compare two merkle trees & get one of the different data blocks num 
    printf("the differnt block is (0 for no different) : %d\n", tree_cmp(&mt_a, &mt_b, 1));

    
    //free merkle tree objects
    freeMerkleTree(&mt_a);
    freeMerkleTree(&mt_b);
    return 0;
}