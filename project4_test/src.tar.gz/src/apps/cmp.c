#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "merkle_tree.c"

//merkle tree test
#define TREE_HEIGHT 4 
#define BLOCK_SIZE 1024
#define DATA_BLOCKS 8 


int main()
{
    int i;
    unsigned char *data[DATA_BLOCKS], *data_copy[DATA_BLOCKS], buffer[BLOCK_SIZE];
    
    // make sure TREE_HEIGHT fits DATA_BLOCKS...
    // BLOCK_SIZE & hash_size, hash_function also needed init
    merkle_tree mt_a = {0, TREE_HEIGHT, MD5_DIGEST_LENGTH, BLOCK_SIZE, DATA_BLOCKS, MD5One, NULL};
    merkle_tree mt_b = {0, TREE_HEIGHT, MD5_DIGEST_LENGTH, BLOCK_SIZE, DATA_BLOCKS, MD5One, NULL};

    for (i=0; i<BLOCK_SIZE; i++)
        buffer[i] = 'A';
    for (i=0; i<DATA_BLOCKS; i++) {
        data[i] = (unsigned char *)malloc(sizeof(char) * BLOCK_SIZE);
        data_copy[i] = (unsigned char *)malloc(sizeof(char) * BLOCK_SIZE);
        memcpy(data[i], buffer, BLOCK_SIZE);
        memcpy(data_copy[i], buffer, BLOCK_SIZE);
    }

    //build tree mt_a with data
    build_tree(&mt_a, data);
    
    //modify a little
    data_copy[7][0]='B';
    build_tree(&mt_b, data_copy);

    print_tree(&mt_a);
    print_tree(&mt_b);

    //compare two merkle trees & get one of the different data blocks num 
    printf("the differnt block is (0 for no different) : %d\n", tree_cmp(&mt_a, &mt_b, 1));

    //modify back, set the merkle tree data block
    set_tree_data(&mt_b, 8, buffer);

    print_tree(&mt_a);
    print_tree(&mt_b);

    //compare again...
    printf("the differnt block is (0 for no different) : %d\n", tree_cmp(&mt_a, &mt_b, 1));
    
    //free merkle tree objects
    freeMerkleTree(&mt_a);
    freeMerkleTree(&mt_b);
    return 0;
}